import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import compression from 'compression';
import { json, urlencoded } from 'express';
import helmet from 'helmet';
import { LoggerService } from '@common/logger/logger.service';
import { AppModule } from '@core/app.module';
import { StartupDashboardService } from '@common/startup/startup.service';
import { setupSwagger } from '@core/swagger/swagger.config';
import { ValidationException } from '@common/exceptions';
import { SECURITY_CONSTANTS } from '@common/security';

async function bootstrap() {
  const startTime = Date.now();

  const app = await NestFactory.create(AppModule, {
    bufferLogs: true,
    bodyParser: false,
  });

  const loggerService = app.get(LoggerService);
  app.useLogger(loggerService);

  const configService = app.get(ConfigService);
  const isProd = configService.get<string>('app.env') === 'production';
  const helmetCsp = configService.get<boolean>(
    'app.security.helmetCspEnabled',
    true,
  );
  const helmetCoep = configService.get<boolean>(
    'app.security.helmetCoepEnabled',
    true,
  );

  app.use(
    helmet({
      contentSecurityPolicy: isProd && helmetCsp ? undefined : false,
      crossOriginEmbedderPolicy: isProd && helmetCoep,
      crossOriginResourcePolicy: false,
    }),
  );

  const expressInstance = app.getHttpAdapter().getInstance();
  const proxyCount = configService.get<number>(
    'app.security.trustProxyCount',
    1,
  );
  expressInstance.set('trust proxy', proxyCount);

  const jsonLimit = configService.get<string>(
    'app.security.bodyJsonLimit',
    SECURITY_CONSTANTS.MAX_JSON_SIZE,
  );
  const urlencodedLimit = configService.get<string>(
    'app.security.bodyUrlencodedLimit',
    SECURITY_CONSTANTS.MAX_URLENCODED_SIZE,
  );
  app.use(
    json({
      limit: jsonLimit,
      verify: (req: any, _res, buf) => {
        req.rawBody = buf;
      },
    }),
  );
  app.use(urlencoded({ extended: true, limit: urlencodedLimit }));

  app.use(compression());

  app.setGlobalPrefix('api/v1', {
    exclude: ['health', 'api/docs'],
  });

  const corsOrigin = configService.get<string>('app.cors.origin', '*');
  const corsMethods = configService.get<string>(
    'app.cors.methods',
    'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
  );
  const corsHeaders = configService.get<string>(
    'app.cors.allowedHeaders',
    'Content-Type,Accept,Authorization,x-correlation-id,x-request-id',
  );

  app.enableCors({
    origin: (
      origin: string | undefined,
      callback: (err: Error | null, allow?: boolean) => void,
    ) => {
      if (!origin || corsOrigin === '*' || corsOrigin === 'true' || corsOrigin === '') {
        return callback(null, true);
      }
      const allowedOrigins = corsOrigin.split(',').map((o) => o.trim());
      if (allowedOrigins.includes(origin) || allowedOrigins.includes('*')) {
        return callback(null, true);
      }
      if (origin.endsWith('.vercel.app') || origin.includes('localhost')) {
        return callback(null, true);
      }
      callback(null, true);
    },
    methods: corsMethods,
    allowedHeaders: corsHeaders,
    credentials: true,
  });

  app.enableShutdownHooks();

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
      exceptionFactory: (errors) => {
        const messages = errors.map(
          (err) =>
            `${err.property}: ${Object.values(err.constraints || {}).join(', ')}`,
        );
        return new ValidationException(messages.join('; '), 'INVALID_INPUT', {
          validationErrors: messages,
        });
      },
    }),
  );

  setupSwagger(app, configService);

  const port = configService.get<number>('app.port', 4000);

  await app.listen(port, '0.0.0.0');

  const startupDashboardService = app.get(StartupDashboardService);
  await startupDashboardService.printDashboard(startTime);
}

bootstrap().catch((err) => {
  console.error('Fatal bootstrapping exception occurred:', err);
  process.exit(1);
});
