const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const products = await prisma.product.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    select: { id: true, name: true, status: true, isPublished: true, visibility: true }
  });
  console.log(JSON.stringify(products, null, 2));
  await prisma.$disconnect();
}

main();
