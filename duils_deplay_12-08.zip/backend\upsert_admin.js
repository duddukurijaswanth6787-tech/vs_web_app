const { PrismaClient } = require('@prisma/client');
const argon2 = require('argon2');

async function createAdmin() {
  const prisma = new PrismaClient();
  
  // Hash password
  const passwordHash = await argon2.hash('Admin@123');
  
  // Find admin role
  const adminRole = await prisma.role.findUnique({ where: { name: 'super_admin' } });
  
  if (!adminRole) {
    console.error('Admin role "super_admin" not found in DB! Check roles table.');
    process.exit(1);
  }

  // Upsert Admin (Use email as unique constraint)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@vasanthi.com' },
    update: {
      passwordHash: passwordHash,
      userType: 'ADMIN',
      accountStatus: 'ACTIVE',
      isEmailVerified: true,
    },
    create: {
      email: 'admin@vasanthi.com',
      passwordHash: passwordHash,
      firstName: 'Admin',
      lastName: 'User',
      userType: 'ADMIN',
      accountStatus: 'ACTIVE',
      isEmailVerified: true,
    }
  });

  const roleLink = await prisma.userRole.findFirst({
    where: { userId: admin.id, roleId: adminRole.id }
  });
  if (!roleLink) {
    await prisma.userRole.create({
      data: { userId: admin.id, roleId: adminRole.id }
    });
  }

  console.log('Admin user upserted successfully:', admin.email);
  await prisma.$disconnect();
}

createAdmin().catch(console.error);
